package Table;

import java.util.ArrayList;
import java.util.List;

public class test {
    protected List<String> list = new ArrayList<>();
    public static void main(String[] args) {

    }
    public void test () {
        list.add("1");
    }
}
