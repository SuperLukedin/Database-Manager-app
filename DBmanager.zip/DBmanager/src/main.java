import java.io.IOException;

public class main {
    //public List<>
    public static void main(String[] args) throws IOException {
//        Geocoder geocoder = new Geocoder();
//        List<GeocoderResult> result;
//        //向google发送获取地址详细请求
//        GeocoderRequest geocoderRequest = new GeocoderRequestBuilder().setAddress("15-17 ANN STREET Newark").setLanguage("en").getGeocoderRequest();
//        //获得google的反馈
//        GeocodeResponse geocoderResponse = geocoder.geocode(geocoderRequest);
//        result = geocoderResponse.getResults();
//
//        //获取地址经纬度信息
//        float lat = result.get(0).getGeometry().getLocation().getLat().floatValue();
//        float lng = result.get(0).getGeometry().getLocation().getLng().floatValue();
//
//        System.out.println(result.get(0).getFormattedAddress());
//        System.out.println("lat/lng=" + lat + "," + lng);
//        Geo geo = new Geo("401 summit st");
//////        float lat = geo.getLatLong()[0];
//////        float lng = geo.getLatLong()[1];
////            float lat = geo.getLatLong().get(0);
////            float lng = geo.getLatLong().get(1);
////        System.out.println(lat + " " + lng);






    }
}
