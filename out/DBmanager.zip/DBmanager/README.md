# Database-Manager

This is a database gui application written in Java. The GUI is currently applied mySQL as an example.</br>
</br>
MySQL.properties saves the user, password and url to your database. You can change it to your own password of mysql database.</br>
If you are using root, and localhost:3306(default settings), you only need to change the password towards your own mySQL database.</br>
